import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kotszer-card',
  templateUrl: './kotszer-card.component.html',
  styleUrls: ['./kotszer-card.component.scss']
})
export class KotszerCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
