export interface Code {
  title:string;
  creation: Date;
  }