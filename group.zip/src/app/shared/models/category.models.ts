export interface Category{
    title: string;
    icon: string;
    value: string;
    color: string;
    url:string;

}