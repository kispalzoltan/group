export const environment = {
  firebaseConfig:{
    apiKey: "AIzaSyBRW27LUqlen_uHbXNNax-gODoIzSRISyo",
    authDomain: "group-3074d.firebaseapp.com",
    projectId: "group-3074d",
    storageBucket: "group-3074d.appspot.com",
    messagingSenderId: "652884014024",
    appId: "1:652884014024:web:e5a2c2e85fe837246006fd",
    measurementId: "G-SBLLFGF472"
  },
  production: true
};
